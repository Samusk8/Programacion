package ejercicios.Utilidades;

public class NumeroAleatorio {
        public static int aleatorio() {
            int numeroAleatorio = (int) (Math.random()*100+1);
            return numeroAleatorio;
        }
    }

