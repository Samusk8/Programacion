package ejercicios;

public class Task1 {
    public static void simpatico(String nombre){
        System.out.println("Hola " + nombre);
    }

    public static void main(String[] args) {
        simpatico("wisdom");
    }
}
