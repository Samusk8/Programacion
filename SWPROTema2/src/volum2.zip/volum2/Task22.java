package volum2;

public class Task22 {
    public static void main(String[] args) {
        int numero = 2;
        int resultado = 1;
        for (int i = 1; i <= numero ; i++) {
            resultado = resultado * i;
        }
        System.out.println( resultado);
    }
}
