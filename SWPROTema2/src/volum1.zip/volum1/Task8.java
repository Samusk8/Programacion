package volum1;

public class Task8 {
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        if (a>b){
            System.out.println("a>b");
        } else if (a<b) {
            System.out.println("a<b");
        } else {
            System.out.println("a=b");
        }
    }
}
