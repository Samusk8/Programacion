
//Donada una velocitat v expressada en km/h passar-la a m/s (v*1000/3600). Fes el càlcul amb decimals.

package volum1;

public class Task2 {
    public static void main(String[] args) {
        float v = 40;
        v = v*1000/3600;
        System.out.println(v+" metros por segundo");
    }
}
