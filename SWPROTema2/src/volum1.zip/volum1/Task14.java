// todo Defineix dues variables de tipus sencer, anomenades inici i fi, i assigna-li valors, de manera que inici<=fi. Mostra per pantalla tots els sencers entre inici i fi (inclosos) utilitzant un while.

package volum1;

public class Task14 {
    public static void main(String[] args) {
        int inicio = 0;
        int fi = 30;
        while (inicio<=fi){
            System.out.println(inicio);
            inicio++;
        }

    }
}
