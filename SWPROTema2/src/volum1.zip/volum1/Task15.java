// todo Repeteix l'exercici anterior utilitzant un for.

package volum1;

public class Task15 {
    public static void main(String[] args) {
        int fi = 30;
        for (int inicio = 0; inicio <= fi ; inicio++) {
            System.out.println(inicio);

        }
    }
}
