package volum1;

public class Task6 {
    public static void main(String[] args) {
        int a = 4;
        int b = 5;
        if (a>=b){
            System.out.println("El mayor es a");
        } else {
            System.out.println("el mayor es b");
        }
    }
}
