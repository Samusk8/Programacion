// todo Repeteix l'exercici amb un do{}while().

package volum1;

public class Task16 {
    public static void main(String[] args) {
        int inicio = 0;
        int fi = 30;
        do {
            System.out.println(inicio);
            inicio++;
        } while (inicio<=fi);
    }
}
