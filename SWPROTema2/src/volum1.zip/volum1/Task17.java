// todo Quina diferència hi ha entre els tres exercicis si inici>fi? Mostra l'explicació per pantalla.


package volum1;

public class Task17 {
    public static void main(String[] args) {
        System.out.println("En el while, decimos que genere los numeros mientras se cumpla la condición, y cuando se deja de cumplir sale.");
        System.out.println("Con el do{}while(), a diferencia de while sin mas, hace que el codigo se repita, al menos, una vez");
        System.out.println("Con el for, generamos valores entre un rango de digitos determinado por el usuario ");
    }
}

